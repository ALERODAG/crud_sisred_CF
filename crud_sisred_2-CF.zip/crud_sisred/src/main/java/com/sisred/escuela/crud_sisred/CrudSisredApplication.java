package com.sisred.escuela.crud_sisred;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudSisredApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudSisredApplication.class, args);
	}

}
