package com.sisred.escuela.crud_sisred.productos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sisred.escuela.crud_sisred.models.Producto;


public interface ProductosRepository extends JpaRepository<Producto, Integer> {
	

}
