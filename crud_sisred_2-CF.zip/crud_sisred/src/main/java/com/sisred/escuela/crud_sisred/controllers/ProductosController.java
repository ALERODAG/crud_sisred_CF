package com.sisred.escuela.crud_sisred.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sisred.escuela.crud_sisred.models.Producto;
import com.sisred.escuela.crud_sisred.models.ProductoDto;
import com.sisred.escuela.crud_sisred.productos.ProductosRepository;

import jakarta.validation.Valid;


@Controller
@RequestMapping("productos")
public class ProductosController {
	@Autowired
	
	private ProductosRepository repo;
	
	@GetMapping({" ","/"})
	
	public String mostrarListaProductos (Model model) {
		List<Producto> productos = repo.findAll(Sort.by(Sort.Direction.DESC,"id"));
		model.addAttribute("productos", productos);
		return "productos/index";
		
	}
	
	@GetMapping ("/Crear")
	public String showCreatePage (Model model) {
		ProductoDto productoDto =new ProductoDto();
		model.addAttribute("productoDto", productoDto);
		return "productos/crearproductos";
		
		
	}
	@PostMapping("/crear")
	public String crearProducto(
	@Valid @ModelAttribute ProductoDto productoDto,
	BindingResult resultado) {
	if(productoDto.getArchivoImagen().isEmpty()) {
	resultado.addError(new FieldError("productoDto","archivoImagen"
	,"El archivo para la imagen es obligatorio"));
	}
	if(resultado.hasErrors()) {
	return "productos/CrearProducto";
	}
	return "redirect:/productos";
	

	}
	
}
	