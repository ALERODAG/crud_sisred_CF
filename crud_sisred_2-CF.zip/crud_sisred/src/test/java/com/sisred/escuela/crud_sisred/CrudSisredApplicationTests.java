package com.sisred.escuela.crud_sisred;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSisredApplicationTests {

	@Test
	void contextLoads() {
	}

}
