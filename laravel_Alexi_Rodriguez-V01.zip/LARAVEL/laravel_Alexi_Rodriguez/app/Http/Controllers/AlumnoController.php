<?php
namespace App\Http\Controllers;

use App\Models\Alumno;
use Illuminate\Http\Request;

class AlumnoController extends Controller
{
    public function index()
    {
        //mostramos la informacion en un formato Json
       $alumnos = Alumno::all();
        //return $alumnos;
       return view('alumnos.index', compact('alumnos')); // mostramos la informacion de la base de datos en la vista creadad en index
    }

    public function create()
    {
        return view('alumnos.create');
    }

    public function store(Request $request)
    {
//para guardaqr en la base de datos
        $alumnos = new Alumno();
        $alumnos -> nombre = $request -> input('nombre');
        $alumnos -> apellidos = $request -> input('apellidos');
        $alumnos -> fecha_nacimiento = $request -> input('fecha_nacimiento');
        $alumnos -> direccion = $request -> input('direccion');
        $alumnos -> telefono = $request -> input('telefono');
        $alumnos -> email = $request -> input('email');


        $alumnos -> save();
        return 'Registro guardado con exito';

        return redirect()->route('alumnos.index');

    }

    // Mostrar un alumno específico
    public function show($id)
    {
        $alumno = Alumno::findOrFail($id);
        return view('alumnos.show', compact('alumno'));
    }

    // Mostrar el formulario para editar un alumno existente
    public function edit($id)
    {
        $alumno = Alumno::findOrFail($id);
        return view('alumnos.edit', compact('alumno'));
    }


    // Otros métodos como edit, update, show, destroy pueden ser agregados aquí






}
