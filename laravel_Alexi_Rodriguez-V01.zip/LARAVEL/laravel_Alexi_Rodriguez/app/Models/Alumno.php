<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Alumno extends Model
{
    use HasFactory;

    // // Define la tabla asociada (opcional si el nombre sigue la convención de Laravel)
    // protected $table = 'alumnos';

    // // Define los campos que se pueden asignar masivamente
    // protected $fillable = [
    //     'nombre', 'apellidos', 'fecha_nacimiento', 'direccion', 'telefono', 'email',
    // ];
}
