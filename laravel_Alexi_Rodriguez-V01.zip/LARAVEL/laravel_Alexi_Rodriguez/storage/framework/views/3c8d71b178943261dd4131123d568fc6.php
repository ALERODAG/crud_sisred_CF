<?php $__env->startSection('titulo',' Listado de Cursos'); ?>

<?php $__env->startSection('contenido'); ?>
<br>
<h3 class="text-center">Listado de Asignaturas disponibles</h3>
<br>
<div class="row">

   <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cursito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm">
            <div class="card" style="width: 18rem;">
                <img src="https://th.bing.com/th/id/OIP.Eig1X3X8ly47ziSwRFP8WQHaGn?w=230&h=206&c=7&r=0&o=5&dpr=1.1&pid=1.7" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($cursito->nombre); ?></h5>
                  <p class="card-text"><?php echo e($cursito->descripcion); ?></p>
                  <a href="#" class="btn btn-primary">Ver detalles</a>
                </div>
              </div>
        </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Documents\Dell\LARAVEL\laravel_Alexi_Rodriguez\resources\views/cursos/index.blade.php ENDPATH**/ ?>