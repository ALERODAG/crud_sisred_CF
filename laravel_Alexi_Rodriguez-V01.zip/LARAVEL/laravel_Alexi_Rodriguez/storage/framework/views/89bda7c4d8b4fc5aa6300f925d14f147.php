<?php $__env->startSection('SISRED', 'crear curso'); ?>
<?php $__env->startSection('contenido'); ?>
    <br>
    <h3>Crear nuevo curso</h3>
    <form action="/cursos" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nombrecurso" class="form-label">Nombre del curso</label>
            <input type="texto" class="form-control" id="nombre" name="nombre">

        </div>
        <div class="mb-3">
            <label for="descripcion" class="form-label">Descripcion del curso</label>
            <input type="texto" class="form-control" id="descripcion" name="descripcion">
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Documents\Dell\LARAVEL\laravel_Alexi_Rodriguez\resources\views/cursos/create.blade.php ENDPATH**/ ?>