<br>
<h3 class="text-center">Listado de Alumnos</h3>

<br>
<div class="row">

    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm">

        </div>

        <div class="mb-3">
            <table>
                <tbody>
                    <tr>
                        <th scope="row"><?php echo e($alumno->id); ?></th>
                        <th>
                            <label for="nombre" class="form-label"><?php echo e($alumno->nombre); ?></label>
                            <label for="nombre" class="form-label"><?php echo e($alumno->apellidos); ?></label>

                        </th>

                        <th><label for="apellidos" class="form-label"><?php echo e($alumno->direccion); ?></label></th>
                        <th> <label for="telefono" class="form-label"><?php echo e($alumno->telefono); ?></label></th>
                        <th>  <img src="https://th.bing.com/th/id/OIP.EUXFcT6OZYHHwS52PkefHQHaHa?w=190&h=190&c=7&r=0&o=5&dpr=1.1&pid=1.7" class="card-img-top" alt="..." height="60px" ></th>
                    </tr>
                </tbody>

            </table>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\dell\Documents\Dell\LARAVEL\laravel_Alexi_Rodriguez\resources\views/alumnos/index.blade.php ENDPATH**/ ?>