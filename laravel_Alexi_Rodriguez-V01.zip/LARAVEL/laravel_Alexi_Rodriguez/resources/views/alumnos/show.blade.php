<!-- resources/views/alumnos/show.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalle del Alumno</h1>
        <div class="card">
            <div class="card-header">
                {{ $alumno->nombre }} {{ $alumno->apellidos }}
            </div>
            <div class="card-body">
                <p><strong>Fecha de Nacimiento:</strong> {{ $alumno->fecha_nacimiento }}</p>
                <p><strong>Dirección:</strong> {{ $alumno->direccion }}</p>
                <p><strong>Teléfono:</strong> {{ $alumno->telefono }}</p>
                <p><strong>Email:</strong> {{ $alumno->email }}</p>
            </div>
        </div>
        <a href="{{ route('alumnos.index') }}" class="btn btn-primary mt-3">Volver a la lista</a>
    </div>
@endsection
