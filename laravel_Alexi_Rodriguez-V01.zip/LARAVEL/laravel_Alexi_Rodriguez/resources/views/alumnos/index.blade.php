<br>
<h3 class="text-center">Listado de Alumnos</h3>

<br>
<div class="row">

    @foreach ($alumnos as $alumno)
        <div class="col-sm">

        </div>

        <div class="mb-3">
            <table>
                <tbody>
                    <tr>
                        <th scope="row">{{ $alumno->id }}</th>
                        <th>
                            <label for="nombre" class="form-label">{{ $alumno->nombre }}</label>
                            <label for="nombre" class="form-label">{{ $alumno->apellidos }}</label>

                        </th>

                        <th><label for="apellidos" class="form-label">{{ $alumno->direccion }}</label></th>
                        <th> <label for="telefono" class="form-label">{{ $alumno->telefono }}</label></th>
                        <th>  <img src="https://th.bing.com/th/id/OIP.EUXFcT6OZYHHwS52PkefHQHaHa?w=190&h=190&c=7&r=0&o=5&dpr=1.1&pid=1.7" class="card-img-top" alt="..." height="60px" ></th>
                    </tr>
                </tbody>

            </table>
        </div>
    @endforeach
