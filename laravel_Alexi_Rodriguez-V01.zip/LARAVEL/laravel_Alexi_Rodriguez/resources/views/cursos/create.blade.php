@extends('layouts.app')
@section('SISRED', 'crear curso')
@section('contenido')
    <br>
    <h3>Crear nuevo curso</h3>
    <form action="/cursos" method="post">
        @csrf
        <div class="mb-3">
            <label for="nombrecurso" class="form-label">Nombre del curso</label>
            <input type="texto" class="form-control" id="nombre" name="nombre">

        </div>
        <div class="mb-3">
            <label for="descripcion" class="form-label">Descripcion del curso</label>
            <input type="texto" class="form-control" id="descripcion" name="descripcion">
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
@endsection
