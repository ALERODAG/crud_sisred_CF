@extends('layouts.app')
@section('titulo',' Listado de Cursos')

@section('contenido')
<br>
<h3 class="text-center">Listado de Asignaturas disponibles</h3>
<br>
<div class="row">

   @foreach ($course as $cursito)
        <div class="col-sm">
            <div class="card" style="width: 18rem;">
                <img src="https://th.bing.com/th/id/OIP.Eig1X3X8ly47ziSwRFP8WQHaGn?w=230&h=206&c=7&r=0&o=5&dpr=1.1&pid=1.7" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">{{$cursito->nombre}}</h5>
                  <p class="card-text">{{$cursito->descripcion}}</p>
                  <a href="#" class="btn btn-primary">Ver detalles</a>
                </div>
              </div>
        </div>
   @endforeach

</div>

@endsection
